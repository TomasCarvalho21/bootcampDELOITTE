### Example questions to use when testing your chatbot:

1. What are the greenhouse gases?
3. How are indigenous people being affected by climate change?
4. What should be the percent reduction in global passenger car fleet emissions by 2050?
5. What are emission factors, and how are they determined?
6. What is the main problematic greenhouse gas and what are its causes?
7. I want to give a gift to someone living in France, with an item of clothing. What do you suggest?
